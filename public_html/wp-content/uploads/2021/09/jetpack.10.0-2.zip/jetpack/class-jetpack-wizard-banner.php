<?php
/**
 * Deprecated since 9.5.0
 *
 * @deprecated
 * @package automattic/jetpack
 */

// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
_deprecated_file( basename( __FILE__ ), 'jetpack-9.5.0' );
